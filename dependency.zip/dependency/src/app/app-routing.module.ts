import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WholesaleComponent } from './wholesale/wholesale.component';
import { ManufactureComponent } from './manufacture/manufacture.component';
import { Route } from '@angular/compiler/src/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
 
  {path:'wholesale',component:WholesaleComponent },
  {path:'manufacture',component:ManufactureComponent},
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
