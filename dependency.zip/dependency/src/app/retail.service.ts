import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RetailService {
  constructor() { 
  }

  getMed(){
    return [
      {"cp" : 100 ,"name":"crocin",sp:200},
      {"cp":200,"name":"aristrozyme",sp:300},
      {"cp":300,"name":"calcicard",sp:400}
    ];
  }
}
  export class samp{
    greeting: string;
    a:any=10;
    b:any=20;
  constructor() { 
    
  }
  
 
sum()
{
  let c=this.a+this.b;

} 
}

