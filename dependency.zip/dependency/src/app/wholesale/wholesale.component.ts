import { Component, OnInit  } from '@angular/core';
import { RetailService ,samp} from '../retail.service';
import { getRenderedText } from '@angular/core/src/render3';

@Component({
  selector: 'wholesale',
  templateUrl: './wholesale.component.html',
  styleUrls: ['./wholesale.component.css'],
  providers:[RetailService,samp]
})
export class WholesaleComponent implements OnInit {
public med=[];

 s;
  constructor(private medi:RetailService,private samp1:samp) {
    
   }

  ngOnInit() {
    this.med=this.medi.getMed();
    
    this.s=this.samp1.sum();
  }

}
