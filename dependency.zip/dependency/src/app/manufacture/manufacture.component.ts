import { Component, OnInit } from '@angular/core';
import { RetailService } from '../retail.service';

@Component({
  selector: 'manufacture',
  templateUrl: './manufacture.component.html',
  styleUrls: ['./manufacture.component.css']
})
export class ManufactureComponent implements OnInit {
public med1=[];
  constructor(private med:RetailService) { }

  ngOnInit() {
    this.med1=this.med.getMed();
  }

}
