  import { Component, OnInit } from '@angular/core';

  @Component({
    selector: 'app-helloworld',
    templateUrl: './helloworld.component.html'
    ,
    styleUrls: ['./helloworld.component.css']
  })
  export class HelloworldComponent implements OnInit {

      a : any;
      b: any[];
        c:any;
        d:any;
        h:boolean=false;
        visible:boolean=true;
        isLoggedIn:boolean=false;
        favoriteHero:string="Joker"
        favoriteHero2:string="tarun"
        
    constructor() { 
      this.a={
    name  :'Tarun',
    phone: [
      '123456',
      '456789'
    ]
      };
      this.b=['a','b','c','d'];
      this.c=123;
      this.d=456;
    }

    ngOnInit() {
    }
    toggle(){
    
      this.visible = !this.visible;
    }
    
  }
  function abc()
  {
  return (this.a+this.c);

  }
