import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pipe',
  template: `
  <h2> Pipe examples start here </h2>
  <h3> String pipe</h3>
  <p> {{ name1}} </p>,
  <p> {{ name1 | lowercase}}</p>,
  <p> {{ name1 | uppercase}}</p>,
  <p> {{ name1 | slice:0:6}}</p>,
  <p> {{ name2 | json}}</p>
  <h3> Number pipe</h3>
  <p> {{ 5.4789 | number:'1.2-3'}}</p>,
  <p> {{ .2005| number:'1.2-3'}}</p>,
  <p> {{name3 | number:'1.2-3'}}</p>
  <p> {{ 5.4789 | percent}}</p>
  <h3> Currency pipe</h3>
  <p> {{ 5.4789 | currency}}</p>
  <p> {{ 5.4789 | currency:'GBP'}}</p>
  <p> {{ 5.4789 | currency:'GBP':'code'}}</p>
  <h3> Date pipe</h3>
  <p>{{date}}
  <p>------------</p>
  <p>{{date | date:'short'}}
  <p>{{date | date:'medium'}}
  <p>{{date | date:'full'| uppercase}}
  <h3> time pipe</h3>
   <p>{{date | date:'shortTime'}}
  <p>{{date | date:'mediumTime'}}
  <p>{{date | date:'fullTime'}}
  <h3> date pipe </h3>
  <p>{{date | date:'shortDate'}}
  <p>{{date | date:'mediumDate'}}
  <p>{{date | date:'longDate'}}
  <h2> Event binding</h2>

  <button (click)="onClick()">Click Me</button><br>
  <input type="text" [value]='a' size=50><br>
  {{2+3+9}}
  `,
  
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {
  name1 : string
  name2 : any
  name3:number
  date:any
  a:any;
  c:any;
  constructor() {
    this.name1="Hello World";
    this.name3=123
    this.date=new Date();
    this.name2 = {
      firstname : "Tarun",
      lastname : "Agarwal"
      
    }
    this.c="hello"

    }
   

  ngOnInit() {
  }
onClick(){
  //alert (event);
  this.a="U clicked me "
}
}
