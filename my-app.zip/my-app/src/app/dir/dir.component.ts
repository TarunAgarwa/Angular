import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dir',
  templateUrl: './dir.component.html',
  styleUrls: ['./dir.component.css']
})
export class DirComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
