import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'convert',
  templateUrl: './convert.component.html',
  styleUrls: ['./convert.component.css']
})
export class ConvertComponent implements OnInit {
  a: any;
  @Input('name') demo:string;
  constructor() {

  }
  // passing input to the component
  ngOnInit() {
    this.a={
      name : this.demo
    };

  }
  
}
