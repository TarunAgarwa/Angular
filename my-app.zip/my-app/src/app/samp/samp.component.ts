import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'samp',
  templateUrl: './samp.component.html',
  styleUrls: ['./samp.component.css']
})
export class SampComponent implements OnInit {
b:any[];
g:any;
z:any;
condition:boolean;
  constructor() { 
this.b=["cricket","foot","tennis"];
  }
  ngOnInit() {
  }
   Onclick(a)
  {
    let i=0;
   
    this.condition=true;
    console.log(a);
    for( i=0;i<this.b.length;i++)
    {
      if(this.b[i]==a)
      {
      alert("Value already exists"+a)
      
      break;
    }} 
    if(this.b[i]!==a)

    this.b.push(a);
 
}
get(b){
  this.z=b;
}

}

