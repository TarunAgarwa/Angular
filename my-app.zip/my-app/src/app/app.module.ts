import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HelloworldComponent } from './helloworld/helloworld.component';
import { DateComponent } from './date/date.component';
import { ConvertComponent } from './convert/convert.component';
import { PipeComponent } from './pipe/pipe.component';
import { TwowayComponent } from './twoway/twoway.component';
import { FormsModule } from'@angular/forms';
import { LoginComponent } from './login/login.component';
import { DirComponent } from './dir/dir.component';
import { SampComponent } from './samp/samp.component';


@NgModule({
  declarations: [
    AppComponent,
    HelloworldComponent,
    DateComponent,
    ConvertComponent,
    PipeComponent,
    TwowayComponent,
    LoginComponent,
    DirComponent,
    SampComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
