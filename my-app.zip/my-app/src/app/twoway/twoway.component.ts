import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'twoway',
  templateUrl: './twoway.component.html',
  styleUrls: ['./twoway.component.css']
})
export class TwowayComponent implements OnInit {

    sample:string="";
  constructor() { }

  ngOnInit() {
  }

}
