import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.css']
})
export class DateComponent implements OnInit {

  message :string = "Welcome  ";
 
  message1 :string; 
  constructor() { 
//double brackets are used for interpolation which looks for the values in the brackets  are to be evaluated

    setInterval(()=>{
    let c=new Date();
    this.message1= ' ' +c.toLocaleTimeString();
    },1000);
    
  }

  ngOnInit() {
  }
add(a: number,b: number)
{
  return a+b;
}
}
