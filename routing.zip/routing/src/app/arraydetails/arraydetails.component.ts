import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router,ParamMap} from '@angular/router';
 @Component({
  selector: 'arraydetails',
  templateUrl: './arraydetails.component.html',
  styleUrls: ['./arraydetails.component.css']
})
export class ArraydetailsComponent implements OnInit {
public id;
  constructor(private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    //let id =parseInt(this.route.snapshot.paramMap.get('id'));
  //this.id=id;
  this.route.paramMap.subscribe((param: ParamMap)=>{
    let id=parseInt(param.get('id'));
    this.id=id;
  });
  }
prev()
{
let previd=this.id-1;
this.router.navigate(['/Player',previd]);
}
next()
{
let nextid=this.id+1;
this.router.navigate(['/Player',nextid]);
}
}
