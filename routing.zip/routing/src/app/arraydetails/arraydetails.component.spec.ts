import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArraydetailsComponent } from './arraydetails.component';

describe('ArraydetailsComponent', () => {
  let component: ArraydetailsComponent;
  let fixture: ComponentFixture<ArraydetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArraydetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArraydetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
