import { Component, OnInit } from '@angular/core';
import { Play} from './array';
import { Player } from './a';
import{Router} from '@angular/router';


@Component({
  selector: 'array',
  templateUrl: './array.component.html',
  styleUrls: ['./array.component.css']
})
export class ArrayComponent implements OnInit {
 
  Player=Play;
  selectedHero: Player;
 
  constructor(private router: Router) { }
 
  ngOnInit() {
  }
 
  onSelect(Player): void {
    this.router.navigate(['/Player',Player.id]);
  }
}