import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error',
  template: '<h3> Page not found </h3>',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
