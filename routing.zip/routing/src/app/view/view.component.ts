import { Component, OnInit } from '@angular/core';
import { Service } from '../service.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
samp=[];
  constructor(private sam:Service) { }

  ngOnInit() {
    this.samp=this.sam.getMed();
  }

}
