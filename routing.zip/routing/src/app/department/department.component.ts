import { Component, OnInit } from '@angular/core';
import {dept} from './dep';
import {EmpService} from './departmentservice';
import {SalService} from './departmentservice';
import {sal} from './sal';
@Component({
  selector: 'department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css'],
  providers:[EmpService,SalService]
})
export class DepartmentComponent implements OnInit {
department : dept[];
salary: sal[];

  constructor(private deptser:EmpService,private salser:SalService) {
 
   }

  ngOnInit() {
    this.department= this.deptser.getdept();
    this.salary= this.salser.getsal();
  }
  getdept()
  {
    this.deptser.getdept();
  }
  
}
