export interface dept
{
    id:number;
    name:string;
}
