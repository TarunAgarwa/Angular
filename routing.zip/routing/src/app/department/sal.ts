export interface sal
{
    sal:number;
    
}