import { Injectable } from "@angular/core";
import {dept} from './dep';
import {sal} from './sal';
//@Injectable()
export class EmpService
{
    getdept() : dept[]
    {
return[
    {"id": 1, "name": "Angular" },
    {"id": 2, "name": "JAVA" },
    {"id": 3, "name": "HTML" },
    {"id": 4, "name": "JS" },
  ];
}
}
export class SalService
{
    getsal() : sal[]
    {
return[
    {sal:10000 },
    {sal:20000 },
   
  ];
}
}
