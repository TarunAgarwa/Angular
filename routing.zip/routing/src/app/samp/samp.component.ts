import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'samp',
  templateUrl: './samp.component.html',
  styleUrls: ['./samp.component.css']
})
export class SampComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
