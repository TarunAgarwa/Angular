import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';
import { UpdateComponent } from './update/update.component';
import { DeleteComponent } from './delete/delete.component';
import { ViewComponent } from './view/view.component';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { ArrayComponent } from './array/array.component';
import { DepartmentComponent } from './department/department.component';
import { ArraydetailsComponent } from './arraydetails/arraydetails.component';
const routes: Routes = [
  { path:'',redirectTo:'/Home' ,pathMatch:'full' },
  { path:'Add',component:AddComponent },
  {path:'Update',component:UpdateComponent},
  { path:'Delete',component:DeleteComponent },
  { path:'View',component:ViewComponent },
  { path:'Home',component:HomeComponent },
  { path:'Department',component:DepartmentComponent },
  { path:'Player',component:ArrayComponent },
  { path:'Player/:id',component:ArraydetailsComponent },
  { path:"**",component:ErrorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent=[AddComponent,
  UpdateComponent,
  DeleteComponent,
  ViewComponent, 
  HomeComponent,
  ErrorComponent,
  DepartmentComponent,
  ArrayComponent,
  ArraydetailsComponent];